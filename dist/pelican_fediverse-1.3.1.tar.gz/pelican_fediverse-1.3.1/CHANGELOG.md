# 1.3.1 - First PyPI package
pelican-fediverse has been packed for PyPI

# 1.3 - Fediverse fixed tags
You can enter fixed tag(s) to be published on all your contents but only in Mastodon

# 1.2 - Mastodon specific tags
You can enter tags that will not be published on Pelican output but only on Mastodon

# 1.1 - OAuth token login
User/password logis has been deprecated
Implemented OAuth token login
Change file where connection information are stored

# 1.0 - First stable release
Fediverse can publish a text on Mastodon (included tags taken from Pelican content)

# 0.9 - First stable (incomplete) release
